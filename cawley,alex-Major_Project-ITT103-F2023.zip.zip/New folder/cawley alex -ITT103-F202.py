# Here holds the class information about each course. It provides attributes , methods etc.
class Course:
    def __init__(personal_student, course_id_number, name, full_fee):
        personal_student.course_id_number = course_id_number
        personal_student.name = name
        personal_student.full_fee = full_fee 


#  manages student information and enrollment within the course
class Student:
    def __init__(personal_student, students_id_number, name, mail_provider):  
        if not students_id_number.endswith("5223"):  #unique identifier that must be present on student id in order for program to perform certain functions 
            raise ValueError("INVALID STUDENT ID please try again.") # in the case there is incorrect value this error message will be displayed to user
        personal_student.students_id_number = students_id_number
        personal_student.name = name
        personal_student.mail_provider = mail_provider
        personal_student.courses = []
        personal_student.balance = 0.0 #the full amount which a student would owe for enrolled courses
        

    def enroll(personal_student, course):
        if course.course_id_number in [c.course_id_number for c in personal_student.courses]:
            raise ValueError(f"Student is already a class participant in {course.name}.")
        personal_student.courses.append(course)
        personal_student.balance += course.full_fee

    def make_payment(personal_student, total_amount):
        if total_amount < 0:
            raise ValueError("Payment amount is invalid please try again.")
        personal_student.balance -= total_amount
        if personal_student.balance < 0:
            personal_student.balance = 0.0


# class to manage the entire registration system
class RegistrationSystem:
    def __init__(personal_student):
        personal_student.courses = {}
        personal_student.students = {}

    def add_course(personal_student, course_id_number, name, full_fee):
        if course_id_number in personal_student.courses:
            raise ValueError("Course with this ID already exists.")
        personal_student.courses[course_id_number] = Course(course_id_number, name, full_fee)

    def register_student(personal_student, students_id_number, name, mail_provider):
        if not students_id_number.endswith("5223"):
            raise ValueError("Student ID must end with '5223'.")
        if students_id_number in personal_student.students:
            raise ValueError("Student with this ID already exists.")
        personal_student.students[students_id_number] = Student(students_id_number, name, mail_provider)

    def enroll_in_course(personal_student, students_id_number, course_id_number):
        if students_id_number not in personal_student.students:
            raise ValueError("Student not found.")
        if course_id_number not in personal_student.courses:
            raise ValueError("Course not found.")
        student = personal_student.students[students_id_number]
        course = personal_student.courses[course_id_number]
        student.enroll(course)

    def calculate_payment(personal_student, students_id_number, total_amount):
        if students_id_number not in personal_student.students:
            raise ValueError("Student not found.")
        student = personal_student.students[students_id_number]
        if total_amount < 0.4 * student.balance:
            raise ValueError("Payment must be at least 40% of the outstanding balance.")
        student.make_payment(total_amount)

    def students_overall_balance(personal_student, students_id_number):
        if students_id_number not in personal_student.students:
            raise ValueError("Student not found.")
        student = personal_student.students[students_id_number]
        return student.balance

    def show_all_coursess(personal_student):
        if not personal_student.courses:
            return "No courses available."
        return [f"{course.course_id_number}: {course.name} - ${course.full_fee:.2f}" for course in personal_student.courses.values()]

    def show_registered_students(personal_student):
        if not personal_student.students:
            return "No students registered."
        return [f"{student.students_id_number}: {student.name} ({student.mail_provider})" for student in personal_student.students.values()]

    def show_students_in_course(personal_student, course_id_number):
        if course_id_number not in personal_student.courses:
            raise ValueError("Course not found.")
        enrolled_students = [
            student.name
            for student in personal_student.students.values()
            if any(course.course_id_number == course_id_number for course in student.courses)
        ]
        return enrolled_students if enrolled_students else "No students enrolled in this course."


## Manages the students' personal_student information, the courses they are taking, and the remaining balance.
# Unique course identification keys were added and modeled after UCC program keys.
def main():
    registration_system = RegistrationSystem()
    
    while True:
        print("\nuniversity of the common wealth carribbean registration Menu ")
        print("1. Add new course to system") #prompts user to add new course name and full_fee 
        print("2. Register  students")  #this PROMPTS FOR DETAILS REGARDING STUDENTS SUCH AS ID name AND mail_provider SO THEY CAN BE REGISTERED
        print("3. Enroll student in course") #ENclassS STUDENTS WITHIN THE COURSE ,TAKES STUDENT ID
        print("4. Show courses") #DISPLAYS ALL THE AVAILABLE COURSES THATS BEEN REGISTERED IN THE SYSTEM
        print("5. Show all current students") #SHOWS ALL THE STUDENTS CURRENTLY REGISTERED 
        print("6. Show students classed in  course") #SHOWS STUDENTS WITHIN SYSTEM
        print("7. View student financial balance") #HELPS VIEW STUDENTS OFFICIAL BALANCE ON COURSES
        print("8. Make a payment")  #PAYMENT HANDLER ANY DEPOSIT IS MADE THROUGH HERE
        print("9. Exit")  # PROGRAM EXIT OPTION ONCE SELECTED PROGRAM AUTOMATICAALY BREAKS
           #FOR EACH CHOICE SELECTED THE FOLLOWING VALUES ARE RETURNED TO USER IF THERES IS A INCORRECT VALUE USER WILL RECIEVE A VALUE ERROR
        try:
            choice = int(input("Enter your choice: "))

            if choice == 1:
                course_id_number = input("Enter course ID number: ") # ONLY ACCEPTS ID NUMBER ENDING WITH 5223 (TAILORED AFTER UCC ACTUAL ID )
                name = input("Enter name of course: ") 
                full_fee = float(input("Enter course full_fee: "))
                registration_system.add_course(course_id_number, name, full_fee)
                print("Course has been added successfully.")
            elif choice == 2:
                students_id_number = input("Enter student ID NUMBER: ")
                name = input("Enter student full name: ")
                mail_provider = input("Enter student mail_provider (ensure mail provider is used e.g @gmail.com): ")
                registration_system.register_student(students_id_number, name, mail_provider)
                print("Student has been registered successfully.")
            elif choice == 3:
                students_id_number = input("Enter student ID NUMBER: ")
                course_id_number = input("Enter course ID NUMBER: ")
                registration_system.enroll_in_course(students_id_number, course_id_number)
                print("Student Has been enrolled successfully.")
            elif choice == 4:
                courses = registration_system.show_all_coursess()
                print("Courses currently available:")
                print("\n".join(courses))
            elif choice == 5:
                students = registration_system.show_registered_students()
                print("Registered Students:")
                print("\n".join(students))
            elif choice == 6:
                course_id_number = input("Enter course ID NUMBER: ")
                students_in_course = registration_system.show_students_in_course(course_id_number)
                print("Students in Course:")
                print("\n".join(students_in_course))
            elif choice == 7:
                students_id_number = input("Enter student ID (numeric): ")
                balance = registration_system.students_overall_balance(students_id_number)
                print(f"Student Balance: ${balance:.2f}")
            elif choice == 8:
                students_id_number = input("Enter student ID NUMBER: ")
                total_amount = float(input("Enter Amount being paid: "))
                registration_system.calculate_payment(students_id_number, total_amount)
                print("Payment has been processed successfully.")
            elif choice == 9:
                print("Exiting system.")
                break
            else:
                print("Invalid selection DETECTED. Please try again.")

        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f" error: {e}")


if __name__ == "__main__":
    main()

#WHAT MY PROGRAM IS ABOUT
#The program first starts by creating a instance of the registrationsystem 
# afterr this is completed it then enters a loop where thr user can browse throough and 
# performing  operations duch as adding courses registering students  checking balances etc 
#forms of validation i chose to implement was only accepting student id numbers ending with 5223 
# the payment is set to not accept payment atleast 40 percent off the overall balance
#one of the best features of my program is that multiple students can be added 
#my program also does not allow the use of duplicate ids to be used in the system
#and same student cant enrolled in the same course multpile times
#limitations 
#code cannot store data after being exited 
#code does not have a strong validation system and can be easily bypassed due to only accepting numbers ending with 5223 
